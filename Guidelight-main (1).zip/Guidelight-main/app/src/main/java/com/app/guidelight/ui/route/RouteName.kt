package com.app.guidelight.ui.route

object RouteName {
    const val LOGIN = "Login"
    const val REGISTER = "Register"
    const val DASHBOARD = "Dashboard"
    const val NOTIFICATION = "Notification"
}