package com.app.guidelight.data

data class NotificationItem(
    val title: String,
    val message: String,
    val time: String // You can format this as needed
)
